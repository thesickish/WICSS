# The goal of this practicum is to see look at some R that does basic text 
# manipulation and natural language processing. I have borrowed heavily from
# the excellent book "Text Mining with R: A Tidy Approach" by by Julia Silge 
# and David Robinson: https://github.com/dgrtwo/tidy-text-mining.

# The true fact is that until one becomes quite proficent in a language (and 
# afterwards as well), writing code is modifying code. So, what we will do is 
# understand and modify code by Stilge and Robinson.

# We use the following packages:
library(purrr) # functional programming tools for working with vectors
library(dplyr) # a small language for manipulating data frames
library(tidytext) # tools for transforming between text and tidy-style dfs
library(stringr) # tidy-style tools for string manipulation

library(ggplot2) # graphs
library(forcats) # tools for working with categorical variables

library(textstem) # tools for stemming and lemmatizing text

#corpora
library(gutenbergr)
library(janeaustenr)

# Note, Stilge and Robinson are committed the Tidy Data worldview of 
# Hadley Wickham:
# 
# "A huge amount of effort is spent cleaning data to get it ready for analysis, 
# but there has been little research on how to make data cleaning as easy and 
# effective as possible. This paper tackles a small, but important, component of 
# data cleaning: data tidying. Tidy datasets are easy to manipulate, model and 
# visualize, and have a specific structure: each variable is a column, each 
# observation is a row, and each type of observational unit is a table. This 
# framework makes it easy to tidy messy datasets because only a small set of 
# tools are needed to deal with a wide range of un-tidy datasets. This structure 
# also makes it easier to develop tidy tools for data analysis, tools that both 
# input and output tidy datasets. The advantages of a consistent data structure 
# and matching tools are demonstrated with a case study free from mundane data 
# manipulation chores."

# The primary consequence for the code here is that heavy use of is made of 
# pipes. Pipes are beautiful, and likely familiar if you have linux / unix 
# experience or functional programming background. The primary idea is that 
# instead of writing 
# 
# f(g(h(x)))
# 
# which can become quite cumbersome when have more and more nesting, we can just 
# write
# 
# x | h | g | f 
# 
# with the understanding that the output of each function is piped to the next 
# function to the right---or in Tidy style:
# 
# x %>%
#   h %>%
#   g %>%
#   f

# -------------------------------------------------

# The janeaustenr package provides a data frame (here a tibble) with each line 
# of text from Jane Austen's books paired with the book it comes from.

austen <- austen_books()

austen

# The tidytext function unnest_tokens spits a column into tokens using a 
# tokenizer, the default being words, returning a new dataframe. The count 
# function from dplyr allows use to easily count unique variables in a dataframe.

book_words <- austen %>%
  unnest_tokens(word, text) %>%
  count(book, word, sort = TRUE)

book_words

# Let's grab the total number of words for each book so we can compute word 
# frequencies

total_words <- book_words %>% 
  group_by(book) %>% 
  summarize(total = sum(n))

total_words

# We can through those totals back on to the df we're working with.

book_words <- left_join(book_words, total_words)

book_words

# When we plot word frequenct (n/total) we see what we expect. A few words are 
# extremely frequent, but most words are infrequent. 

ggplot(book_words, aes(n/total, fill = book)) +
  geom_histogram(show.legend = FALSE) +
  xlim(NA, 0.0009) +
  facet_wrap(~book, ncol = 2, scales = "free_y")

# This pattern is so common in language it has risen to the level of being 
# called a law, in particular, Zipf's law, named after Harvard linguist 
# George Zipf who worked on phoneme, word, and character frequency 
# (mostly in Mandarin texts) in the early  part of the 20th century. Instead of 
# raw frequency, Zipf's law is usually stated in terms of rank-frequency---i.e., 
# the n-th most common word appears with frequency 1/n.

# We can see this power law at work in Austen's corpus. We group rows by their
# book and then grab the rank order of words, storing that number in its own 
# column with word frequency.

freq_by_rank <- book_words %>% 
  group_by(book) %>% 
  mutate(rank = row_number(), 
         `term frequency` = n/total) %>%
  ungroup()

freq_by_rank

# When we plot rank by word frequency in log space we see the hallmark of a 
# power law, namely a line. 

freq_by_rank %>% 
  ggplot(aes(rank, `term frequency`, color = book)) + 
  geom_line(size = 1.1, alpha = 0.8, show.legend = FALSE) + 
  scale_x_log10() +
  scale_y_log10()

# We can actually get the line and see how close Austen's work conforms to 
# Zipf's law. First, though, not that the linear relationshiop breaks down at 
# the tails. This is common, at least for the infrequent words. They tend to 
# drop off. As Stilge and Robinson note, the fact that the frequent words don't 
# fit the pattern is weird. Austen seems to not like common words. We can throw 
# out the most common and least common words to fit our line.

rank_subset <- freq_by_rank %>%
  filter(rank < 500,
         rank > 10)

# Predict term frequency in terms of rank.

lm(log10(`term frequency`) ~ log10(rank), data = rank_subset)

# Not so bad, Dr. Zipf. A relationship of freq(n) = 1/n on a log-log plot would
# be a line with slope -1. Here we have -1.1. Adding the regression like to the 
# graph shows that we get the bulk of frequency table.

freq_by_rank %>% 
  ggplot(aes(rank, `term frequency`, color = book)) + 
  geom_abline(intercept = -0.6226, slope = -1.1125, 
              color = "gray50", linetype = 2) +
  geom_line(size = 1.1, alpha = 0.8, show.legend = FALSE) + 
  scale_x_log10() +
  scale_y_log10()

# The fact that a few words are extremely frequent, and that these words tend to 
# be the same across texts presentes a challenge for determining comparing 
# texts. E.g., We don't just want to say that two texts are similar if they have 
# the  words in them. Any such analysis would be swamped by these super frequent 
# words.  We want to instead de-weight generally common words and pick out words 
# the are generally uncommon but occur frequently in the texts in questiion. 
# tf-idf is a simple, effective way to do this.
# 
# tf-idf (term frequency-inverse document frequency) is defined as 
# 
# tf(t,d) * idf(t,d)
# 
# where tf(t,d) is the frequence of term t in document d and idf(t,d) is the 
# inverse document frequency
# 
# idf(t,d) = (number of texts in d's corpus / number of texts in d's corpus containing t)

# The tidytext package provides a tf-idf function out of the box.

book_tf_idf <- book_words %>%
  bind_tf_idf(word, book, n)

book_tf_idf

# flip the order so we see high-scoring words

book_tf_idf %>%
  select(-total) %>%
  arrange(desc(tf_idf))

# Let's plot the 15 highest scoing words and their tf-idf scores.

book_tf_idf %>%
  group_by(book) %>%
  slice_max(tf_idf, n = 15) %>%
  ungroup() %>%
  ggplot(aes(tf_idf, fct_reorder(word, tf_idf), fill = book)) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~book, ncol = 2, scales = "free") +
  labs(x = "tf-idf", y = NULL)

# Think for a moment about what these results tell us? How might it change if 
# we examined these books in a different corpus?

# ------------------------------------------------------

# Ok, let's quickly do the same kind tf-idf analysis for a set of texts by 
# physicists. The following code should make sense now with little comment.

physics <- gutenberg_download(c(37729, 14725, 13476, 30155), 
                              meta_fields = "author")

physics_words <- physics %>%
  unnest_tokens(word, text) %>%
  count(author, word, sort = TRUE)

physics_words

plot_physics <- physics_words %>%
  bind_tf_idf(word, author, n) %>%
  mutate(author = factor(author, levels = c("Galilei, Galileo",
                                            "Huygens, Christiaan", 
                                            "Tesla, Nikola",
                                            "Einstein, Albert")))

plot_physics %>% 
  group_by(author) %>% 
  slice_max(tf_idf, n = 15) %>% 
  ungroup() %>%
  mutate(word = reorder(word, tf_idf)) %>%
  ggplot(aes(tf_idf, word, fill = author)) +
  geom_col(show.legend = FALSE) +
  labs(x = "tf-idf", y = NULL) +
  facet_wrap(~author, ncol = 2, scales = "free")

# What you can see is that there is a bit of junk in here. We don't care so much
# about what variable names these authors use or that Tesla seems to like to
# label figures.

# We can deal with this by building a list of corpus specific stopwords to remove 
# from our analysis.

mystopwords <- tibble(word = c("eq", "co", "rc", "ac", "ak", "bn", 
                               "fig", "file", "cg", "cb", "cm",
                               "ab", "_k", "_k_", "_x"))

physics_words <- anti_join(physics_words, mystopwords, 
                           by = "word")
# Redo the tf-idf analysis.

plot_physics <- physics_words %>%
  bind_tf_idf(word, author, n) %>%
  mutate(word = str_remove_all(word, "_")) %>%
  group_by(author) %>% 
  slice_max(tf_idf, n = 15) %>%
  ungroup() %>%
  mutate(word = reorder_within(word, tf_idf, author)) %>%
  mutate(author = factor(author, levels = c("Galilei, Galileo",
                                            "Huygens, Christiaan",
                                            "Tesla, Nikola",
                                            "Einstein, Albert")))

ggplot(plot_physics, aes(word, tf_idf, fill = author)) +
  geom_col(show.legend = FALSE) +
  labs(x = NULL, y = "tf-idf") +
  facet_wrap(~author, ncol = 2, scales = "free") +
  coord_flip() +
  scale_x_reordered()

# This is better, but note that Einstein's work is distinguished by having both 
# the words ordinates and ordinate. This is not so good they are the same word, 
# just with different verbal agreement. Similarly, note that Huygens has both
# "spheroids" and "spheroid". These are not distinct topics. The problem is that
# our corpus is not lemmatized.
# 
# Lemmatization concerns the recostruction of a root word by removing all
# inflection. The textstem package provides a functiion for lemmatization. For 
# instance, consider the following list of words.

x <- c("culturing", "cultured", "cultures", "culture")

# Our intuition is that these words all have the same root. We can access that 
# through lemmatization.

lemmatize_strings(x, dictionary = lexicon::hash_lemmas)

# Your task:
### (1) lemmatize our physics dataframe that has had the stopwords removed.
### (2) run the tf-idf analysis on our new lemmatized corpus an visualize the resuls.
### (3) check if Zipf's law holds in our lemmatized physics corpus.




