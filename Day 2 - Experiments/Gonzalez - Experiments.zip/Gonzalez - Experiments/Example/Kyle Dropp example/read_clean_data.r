

#########################
## clear workspace
## load R libraries
#########################

rm(list=ls())
library(car)
library(ggplot2)
library(reshape)
library(survey)


#########################
## Import CSV file from Qualtrics
## The file has two lines of string headers
#########################
df.raw = read.csv("http://dl.dropboxusercontent.com/u/24660992/conjoint/data_feb_survey.csv",skip=0,head=T)
varnames = names(df.raw)
df.raw2 = read.csv("http://dl.dropboxusercontent.com/u/24660992/conjoint/data_feb_survey.csv",skip=2,head=F)
names(df.raw2)=varnames


#########################
## Subset Data
## Only rows where zip code and newspaper was returned and completed survey
#########################
df = subset(df.raw2,Q168==2&df.raw2$Q711_1_TEXT!=""&df.raw2$Q312_2!=""&df.raw2$Q326_2!=""&df.raw2$Q341_2!=""&df.raw2$demPolIdeo>=1)  


df$id = seq(1,nrow(df))

#########################
## Recode variables for weighting
#########################

## Age Seven Part
df$demAge7 = rep(NA,dim(df)[1])
df$demAge7[df$demAgeFull<=8]<-1 #18-24
df$demAge7[df$demAgeFull>=9&df$demAgeFull<=18]<-2 #25-34
df$demAge7[df$demAgeFull>=19&df$demAgeFull<=28]<-3 #35-44
df$demAge7[df$demAgeFull>=29&df$demAgeFull<=38]<-4 #45-54
df$demAge7[df$demAgeFull>=39&df$demAgeFull<=48]<-5 #55-64
df$demAge7[df$demAgeFull>=49&df$demAgeFull<=58]<-6 #65-74
df$demAge7[df$demAgeFull>=59]<-7 #75+
levels(df$demAge7) = c("18-24","25-34","35-44","45-54","55-64","65-74","75+")

## Age Four Part
df$demAge = rep(NA,dim(df)[1])
df$demAge[df$demAgeFull<=13]<-1
df$demAge[df$demAgeFull>=14&df$demAgeFull<=28]<-2
df$demAge[df$demAgeFull>=29&df$demAgeFull<=48]<-3
df$demAge[df$demAgeFull>=49]<-4
#levels(df$demAge) = c("18-29","30-44","45-64","65+")

## Use five part age - lths, HS grad, Some Coll, Coll Grad, Post+
df$demEduc5 = rep(NA,dim(df)[1])
df$demEduc5[df$demEduFull==1] =1
df$demEduc5[df$demEduFull==2] =4
df$demEduc5[df$demEduFull==3] =3
df$demEduc5[df$demEduFull==4] =2
df$demEduc5[df$demEduFull==5] =3
df$demEduc5[df$demEduFull==6] =5
df$demEduc5[df$demEduFull==7] =3
df$demEduc5[df$demEduFull==8] =5
df$demEduc5[df$demEduFull==10] =1
levels(df$demEduc5) = c("LTHS","HS grad","Some College","College Grad","Postgraduate")

## Census Nine Divisions (http://en.wikipedia.org/wiki/List_of_regions_of_the_United_States#Census_Bureau-designated_areas)
df$demDiv9<-rep(NA,dim(df)[1]) #four regions - northeast, midwest, south, west
df$demDiv9[df$demState %in% c(20,30,46,22,40,7)]<-1
df$demDiv9[df$demState %in% c(33,39,31)]<-2
df$demDiv9[df$demState %in% c(50,23,14,15,36)]<-3
df$demDiv9[df$demState %in% c(26,35,42,28,24,17,16)]<-4
df$demDiv9[df$demState %in% c(8,9,21,47,49,41,34,10,11)]<-5
df$demDiv9[df$demState %in% c(18,43,25,1)]<-6
df$demDiv9[df$demState %in% c(4,19,37,44)]<-7
df$demDiv9[df$demState %in% c(13,27,51,29,45,6,3,32)]<-8
df$demDiv9[df$demState %in% c(2,48,38,12,5)]<-9
levels(df$demDiv9)=c("New England","Mid-Atlantic","East North Central","West North Central",
                     "South Atlantic","East South Central","West South Central","Mountain","Pacific")

#########################
## Append post-stratification weights to the data frame
#########################
source("http://dl.dropboxusercontent.com/u/24660992/conjoint/post_stratify_data.R")


#########################
## stack data frames
## 6 rows per respondent (2 candidates x 3 vignettes)
#########################

cols1 = df[,c("Q711_1_TEXT","Q308",grep("Q312",names(df),value=TRUE)[2:6],"Q309_1","Q310_1","Q311_1")]
cols2 = df[,c("Q711_2_TEXT","Q308",grep("Q312",names(df),value=TRUE)[8:12],"Q316_1","Q317_1","Q318_1")]
cols3 = df[,c("Q711_3_TEXT","Q322",grep("Q326",names(df),value=TRUE)[2:6],"Q328_1","Q329_1","Q330_1")]
cols4 = df[,c("Q711_4_TEXT","Q322",grep("Q326",names(df),value=TRUE)[8:12],"Q335_1","Q336_1","Q337_1")]
cols5 = df[,c("Q711_5_TEXT","Q340",grep("Q341",names(df),value=TRUE)[2:6],"Q344_1","Q345_1","Q346_1")]
cols6 = df[,c("Q711_6_TEXT","Q340",grep("Q341",names(df),value=TRUE)[8:12],"Q349_1","Q350_1","Q351_1")]

## vote selection variable
cols1$selected = ifelse(cols1$Q308==1,1,0)
cols2$selected = ifelse(cols2$Q308==2,1,0)
cols3$selected = ifelse(cols3$Q322==1,1,0)
cols4$selected = ifelse(cols4$Q322==2,1,0)
cols5$selected = ifelse(cols5$Q340==1,1,0)
cols6$selected = ifelse(cols6$Q340==2,1,0)

#########################
## standardize names
#########################
names(cols1) = c("name","vote","weapons","abortion","occupation","endorse","party","support","qualified","ideology","selected")
names(cols2) = c("name","vote","weapons","abortion","occupation","endorse","party","support","qualified","ideology","selected")
names(cols3) = c("name","vote","weapons","abortion","occupation","endorse","party","support","qualified","ideology","selected")
names(cols4) = c("name","vote","weapons","abortion","occupation","endorse","party","support","qualified","ideology","selected")
names(cols5) = c("name","vote","weapons","abortion","occupation","endorse","party","support","qualified","ideology","selected")
names(cols6) = c("name","vote","weapons","abortion","occupation","endorse","party","support","qualified","ideology","selected")



#########################
## newspaper perceptions, policy, demographics
#########################
bkgd = df[,c(grep("^dem",names(df)),  #demos
             grep("^Q305_[1-7]$",names(df)),   #elite perceptions ideology
             grep("^Q303",names(df)),   #elite perceptions bias
             grep("^Q149",names(df)),   # policy qs - general
             grep("^Q303",names(df)),   # policy qs - general
             grep("Q304",names(df)),
             grep("Q201",names(df)),
             grep("Q202",names(df))
)]

stack = cbind(rbind(cols1,cols2,cols3,cols4,cols5,cols6),rbind(bkgd,bkgd,bkgd,bkgd,bkgd,bkgd))
stack$paperPoss = rep(df$zip.newspaper_name2,6)


## recode variables
stack$endorseBin = ifelse(stack$endorse=="",0,1)  #indicator (1=endorse, 0 = no endorse)
stack$ideoDist = abs(stack$Q305_4-stack$demPolIdeo)
stack$ideoDistNotAbs = (stack$Q305_4-stack$demPolIdeo)
stack$ideoPolicy = recode(stack$Q149_1,"1=0;2=1")+recode(stack$Q149_2,"1=0;2=1")+recode(stack$Q149_3,"1=0;2=1")+recode(stack$Q149_4,"1=1;2=0")+recode(stack$Q149_5,"1=0;2=1")+recode(stack$Q149_6,"1=0;2=1")+recode(stack$Q304,"1=0;2=1")

stack$qualHi = ifelse(stack$qualified>=5,1,0)
stack$ideolHi = ifelse(stack$ideology>=5,1,0)
stack$suppHi = ifelse(stack$support>=5,1,0)

stack$qualLo = ifelse(stack$qualified<=3,1,0)
stack$ideoLo = ifelse(stack$ideology<=3,1,0)
stack$suppLo = ifelse(stack$support<=3,1,0)

## Respondent ID
stack$resp_id = rep(seq(1,nrow(df),1),6)

## Vignette ID - this is the number of the choice set
stack$vignette_id = rep(1:3,each=nrow(stack)/3) 

## Respondent - Vignette ID
stack$resp_vignette_id = paste(stack$resp_id,stack$vignette_id,sep="")
stack$resp_vignette_id = as.numeric(as.character(stack$resp_vignette_id))



#########################
#########################
## Run Models
## weighted and unweighted
#########################
#########################

## 1
## Main effects

summary(lm(selected~weapons+abortion+occupation+party
           +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
           +factor(paperPoss)+factor(vignette_id)
           +endorseBin,
           data=stack))

summary(lm(selected~weapons+abortion+occupation+party
           +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
           +factor(paperPoss)+factor(vignette_id)
           +endorseBin,
           data=stack,weight=demWts))


## 2 
## Main effects - read newspaper in last 24 hours

summary(lm(selected~weapons+abortion+occupation+party
           +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
           +factor(paperPoss)+factor(vignette_id)
           +endorseBin,
           data=stack[stack$Q304==1,]))

summary(lm(support~weapons+abortion+occupation+party
           +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
           +factor(paperPoss)+factor(vignette_id)
           +endorseBin,
           data=stack[stack$Q304==1,]))

summary(lm(ideology~weapons+abortion+occupation+party
           +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
           +factor(paperPoss)+factor(vignette_id)
           +endorseBin,
           data=stack[stack$Q304==1,]))

summary(lm(qualified~weapons+abortion+occupation+party
           +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
           +factor(paperPoss)+factor(vignette_id)
           +endorseBin,
           data=stack[stack$Q304==1,]))


summary(lm(selected~weapons+abortion+occupation+party
           +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
           +factor(paperPoss)+factor(vignette_id)
           +endorseBin,
           data=stack[stack$Q304==1,],weight=demWts))



## 3 
## Main effects - read specified paper at least weekly

summary(lm(selected~weapons+abortion+occupation+party
           +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
           +factor(paperPoss)+factor(vignette_id)
           +endorseBin,
           data=stack[stack$Q201_1<=3,]))

summary(lm(support~weapons+abortion+occupation+party
           +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
           +factor(paperPoss)+factor(vignette_id)
           +endorseBin,
           data=stack[stack$Q201_1<=3,]))

summary(lm(ideology~weapons+abortion+occupation+party
           +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
           +factor(paperPoss)+factor(vignette_id)
           +endorseBin,
           data=stack[stack$Q201_1<=3,]))

summary(lm(qualified~weapons+abortion+occupation+party
           +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
           +factor(paperPoss)+factor(vignette_id)
           +endorseBin,
           data=stack[stack$Q201_1<=3,]))

summary(lm(selected~weapons+abortion+occupation+party
           +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
           +factor(paperPoss)+factor(vignette_id)
           +endorseBin,
           data=stack[stack$Q201_1<=3,],weight=demWts))


## 4 
## Party - read newspaper in last 24 hours

for(i in 1:3){
  print(c("GOP","Dems","Indies")[i])
  print(summary(lm(selected~weapons+abortion+occupation+party
                   +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
                   +factor(paperPoss)+factor(vignette_id)
                   +endorseBin,
                   data=stack[stack$Q304==1&stack$demPidNoLn==i,]))) 
}

## 5 
## Main effects - among newspaper readers, ideological distance interaction 1

##
summary(lm(selected~weapons+abortion+occupation+party
           +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
           +factor(paperPoss)+factor(vignette_id)
           +endorseBin*ideoDist,
           data=stack[stack$Q304==1,]))


summary(lm(selected~weapons+abortion+occupation+party
           +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
           +factor(paperPoss)+factor(vignette_id)
           +endorseBin*ideoDist,
           data=stack[stack$Q304==1,],weight=demWts))


## 7 
## Ideology - read newspaper in last 24 hours

summary(lm(selected~weapons+abortion+occupation+party
           +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
           +factor(paperPoss)+factor(vignette_id)
           +endorseBin*ideoDist,
           data=stack[stack$Q201_1<=3&stack$demPolIdeo<=3,]))

## matters for libs, cons, alike
mod1=lm(selected~weapons+abortion+occupation+party
        +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
        +factor(paperPoss)+factor(vignette_id)
        +endorseBin*ideoDist,
        data=stack[stack$Q201_1<=3&stack$demPolIdeo<=5,])


## 7 
## Ideo distance 2 - revealed policy prefs versus newspaper ideo
stack$ideoPolicy2 = (stack$ideoPolicy*6/7)+1
stack$ideoDist2 = abs(stack$ideoPolicy2-stack$demPolIdeo)










stack$ideoDistBin = stack$ideoDist/6


library(apsrtable)
#########################
#### Table in Paper #####
#########################
m1.1 = lm(selected~weapons+abortion+occupation+party
          +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
          +factor(paperPoss)+factor(vignette_id)
          +endorseBin,
          data=stack)

m1.2 = lm(selected~weapons+abortion+occupation+party
          +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
          +factor(paperPoss)+factor(vignette_id)
          +endorseBin*ideoDistBin,
          data=stack)

m1.3 = lm(selected~weapons+abortion+occupation+party
          +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
          +factor(paperPoss)+factor(vignette_id)
          +endorseBin,
          data=stack[stack$Q201_1<=3,])

m1.4 = lm(selected~weapons+abortion+occupation+party
          +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
          +factor(paperPoss)+factor(vignette_id)
          +endorseBin*ideoDistBin,
          data=stack[stack$Q201_1<=3,])

m1.5 = lm(selected~weapons+abortion+occupation+party
          +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
          +factor(paperPoss)+factor(vignette_id)
          +endorseBin,
          data=stack[stack$Q304==1,])

m1.6 = lm(selected~weapons+abortion+occupation+party
          +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
          +factor(paperPoss)+factor(vignette_id)
          +endorseBin*ideoDistBin,
          data=stack[stack$Q304==1,])

apsrtable(m1.1,m1.2,m1.3,m1.4,m1.5,m1.6,digits=3)



#########################
#### Table by Party
#########################

m2.1 = lm(selected~weapons+abortion+occupation+party
          +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
          +factor(paperPoss)+factor(vignette_id)
          +endorseBin,
          data=stack[stack$Q201_1<=3&stack$demPidNoLn==1,])

m2.2 = lm(selected~weapons+abortion+occupation+party
          +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
          +factor(paperPoss)+factor(vignette_id)
          +endorseBin*ideoDist,
          data=stack[stack$Q201_1<=3&stack$demPidNoLn==1,])

m2.3 = lm(selected~weapons+abortion+occupation+party
          +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
          +factor(paperPoss)+factor(vignette_id)
          +endorseBin,
          data=stack[stack$Q201_1<=3&stack$demPidNoLn==2,])

m2.4 = lm(selected~weapons+abortion+occupation+party
          +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
          +factor(paperPoss)+factor(vignette_id)
          +endorseBin*ideoDist,
          data=stack[stack$Q201_1<=3&stack$demPidNoLn==2,])




##############################
### Create Main Effects Figure
###############################

## Input overall summary model here 
## Main effects - read newspaper in last 24 hours

mod1 = (lm(selected~weapons+abortion+occupation+party
           +demAge+factor(demRace)+demHisp+demGender+factor(demEduFull)
           +factor(paperPoss)+factor(vignette_id)
           +endorseBin,
           data=stack[stack$Q201_1<=3,]))


vars=variable.names(mod1)
coefs = c(summary(mod1)$coef[,1])
err = c(summary(mod1)$coef[,2]*1.96)
tvals = c(summary(mod1)$coef[,4])
tmp = data.frame(cbind(coefs,err))

## select particular coefficients
tmp2 = tmp[grep("^weaponsSupports Ban$|^abortionPro-life$|^occupation|^party|^endorseBin$",row.names(tmp)),]
tmp2$name = row.names(tmp2)
tmp2 = tmp2[,c("name","coefs","err")]
names(tmp2) = c("variable","coef","se")

tmp3 = tmp2
tmp3$variable = as.factor(tmp3$variable)
tmp3$coef<-as.numeric(as.vector(tmp3$coef))
tmp3$se<-as.numeric(as.vector(tmp3$se))
tmp3$variable<-c("Favor Assault Weapon Ban","Pro-life","Car Dealer","Carpenter","Doctor","High School Teacher","Lawyer","Member of Congress","Military Veteran", "Independent", "Republican","Newspaper")


variables = read.csv("http://dl.dropboxusercontent.com/u/24660992/conjoint/variables.csv")
for (i in 1:dim(variables)[1]){
  if (sum(tmp3$variable==variables$variable[i], na.rm=T)>0){
    variables$coef[i]<-tmp3$coef[tmp3$variable==variables$variable[i]]
    variables$se[i]<-tmp3$se[tmp3$variable==variables$variable[i]]
  }
}

variables2 = variables
variables2$coef[is.na(variables2$coef)]<-""
variables2$se[is.na(variables2$se)]<-""
variables2$variable<-as.vector(variables2$variable)
variables2$coef<-as.numeric(as.vector(variables2$coef))
variables2$se<-as.numeric(as.vector(variables2$se))

order<-1:dim(variables2)[1]
variables2 <- transform(variables2, variable2=reorder(variable2, -order) ) 

title<-paste("Effects of Candidate Attributes on Candidate Support \n Among Those Who Read Paper Weekly+", sep="")

ggplot(data = variables2, aes(x = coef, y = variable2)) +
  geom_point(aes(colour = group), size = 2.5)+
  geom_errorbarh( aes(y = variable2, xmin = coef - se, xmax = coef + se, height=.28,colour=group),size=.5)+
  xlab("Change in Candidate Support")+
  theme(axis.title.y = element_blank()) +
  geom_vline(xintercept = 0,size=.5,colour="blue",linetype="dotted") +
  theme(axis.text.y = element_text(angle = 0, hjust = 0, color="black"))  +
  ggtitle(title)+
  theme(plot.title = element_text(lineheight=.8, face="bold"))+
  theme(legend.position = "none")












