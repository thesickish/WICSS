



cc <- complete.cases(df[c("demHisp","demGender", "demRace","demAge7","demEduc5","demDiv9")])
n=length(which(cc))

data_2012rv <- df[cc,]

## OPTION 3 (more covariates)
pop.gender <- data.frame(demGender=c("2","1"), Freq=c(0.5342717*n,0.4657283*n))  #2012 cps
pop.age <- data.frame(demAge7=c("1","2","3","4","5","6","7"), Freq=c(0.09485189*n,0.15281863*n,0.15971160*n,0.19251929*n,0.18566851*n,0.12208072*n,0.09234935*n))  #2012 cps
pop.hisp <- data.frame(demHisp=c("1","2"), Freq=c(0.0891*n,0.9109*n))  #2012 cps
pop.race <- data.frame(demRace=c("1","2","3","4","5"), Freq=c(0.008466552*n,0.032779701*n,0.128579846*n,0.814366970*n,0.015806931*n))  #2012 cps
pop.educ <- data.frame(demEduc5=c("1","2","3","4","5"), Freq=c(0.07157311*n,0.27194299*n,0.31378242*n,0.22209648*n,0.12060500*n))  #2012 cps
pop.region <- data.frame(demDiv9=c("1","2","3","4","5","6","7","8","9"), Freq=c(0.05200688*n,0.13035183*n,0.16134013*n,0.07463418*n,0.19986425*n,0.06442249*n,0.10739053*n,0.06743083*n,0.14255888*n))  #2012 cps

##Post-stratification - close to population estimates
design0 <- suppressWarnings(svydesign(id=~1, data=data_2012rv))

design6 <- rake(design0, sample.margins=list(~demHisp,~demGender, ~demAge7,~demRace,~demEduc5,~demDiv9), 
                population.margins=list(pop.hisp,pop.gender, pop.age,pop.race,pop.educ,pop.region),
                control=list(epsilon=.00001, maxit=100, verbose=FALSE))

data_2012rv$wts = weights(design6)

data_merge = data.frame(id=data_2012rv$id,wts=data_2012rv$wts)
idvars = data.frame(id=seq(1,nrow(df)))
data_merge2 = merge(data_merge,idvars,by="id",all=TRUE)
df$demWts = data_merge2$wts
df$demWts = ifelse(is.na(df$demWts),0,df$demWts)

