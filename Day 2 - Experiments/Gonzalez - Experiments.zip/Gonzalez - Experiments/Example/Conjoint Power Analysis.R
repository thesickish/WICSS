install.packages(c(
  "DeclareDesign",
  "fabricatr",
  "randomizr",
  "estimatr",
  "DesignLibrary"
))

library(DeclareDesign)
library(fabricatr)
library(randomizr)
library(estimatr)
library(DesignLibrary)
library(dplyr)

Y_function <- function(data) {
  data %>%
    group_by(pair) %>%
    mutate(Y = if_else(E == max(E), 1, 0)) %>%
    ungroup
}

#pair == number of trials a person sees (i.e., number of times they have to choose)
# candidates == the number of profiles that a participants see for each pair 

design <- 
  declare_population(
    subject = add_level(N = 1000),
    pair = add_level(N = 8),
    candidate = add_level(N = 2, U = runif(N))
  ) +
  declare_assignment(assignment_variable = "A1") +
  declare_assignment(assignment_variable = "A2") +
  declare_assignment(assignment_variable = "A3", 
                     conditions = c("encryption", "hardware", "encrypt and hardware")) +
  declare_assignment(assignment_variable = "A4", 
                     conditions = c("None", "Social Media", "Finance", "Health")) +
  declare_assignment(assignment_variable = "A5")  +
  declare_assignment(assignment_variable = "A6", 
                     conditions = c("None", "Ten", "Fifty")) +
  declare_assignment(assignment_variable = "A7")  +
  declare_step(
    E = 
      0.05 * A1 + 
      0.05 * A2 + 
      0.04 * (A3 == "hardware") + 
      0.08 * (A3 == "encrypt and hardware") + 
      0.02 * (A4 == "Social Media") + 
      0.02 * (A4 == "Finance") + 
      0.02 * (A4 == "Health") + 
      0.05 * A5 + 
      0.04 * (A6 == "Ten") + 
      0.08 * (A6 == "Fifty") + 
      0.05 * A7 + U,
    handler = fabricate) +
  declare_measurement(handler = Y_function) +
  declare_estimator(Y ~ A1 + A2 + A3 + A4 + A5 + A6 + A7,
                    model = lm_robust, term = TRUE)

draw_estimates(design)


simulations_df <- simulate_design(design, sims = 500)

# View(simulations_df)
simulations_df %>% 
  group_by(estimator_label) %>% 
  summarize(power = mean(p.value < .05))


# table(simulations_df$sim_ID)
