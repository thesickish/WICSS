#Conjoint Experiment Data Analysis Example
#Frank J. Gonzalez
#Assistant Professor
#School of Government and Public Policy
#University of Arizona
#fgonzo@arizona.edu

#Prepared for 2021 Winter Institute in Computational Social Science, Tucson, AZ


#####Clear workspace and load R libraries (install packages first if need be)#####

rm(list=ls())

# install.packages("car")
# install.packages("ggplot2")
# install.packages("reshape")
# install.packages("survey")
# install.packages("dplyr")
# install.packages("tidyr")
# install.packages("lme4")
# install.packages("arm")
# install.packages("estimatr")

library(car)
library(ggplot2)
library(reshape)
library(survey)
library(dplyr)
library(tidyr)
library(lme4)
library(arm)
library(estimatr)

#####Set working directory and load data#####

setwd("C:/Users/fgonzo/Dropbox/WICSS 2021/Example") #Change to where your files are

df <- read.csv("WICSS-SampleData-forR.csv")

#Notes on data file:

# - This is fake data from me randomly clicking through a few times. 
# - There are multiple ways to set up the Javascript so that the necessary data are exported to your liking. I use the method recommended by Leeper (https://github.com/leeper/conjoint-example), but since we randomized the order or attributes and they don't in their paper, we need a couple more steps in our code.
# - I also have a standard method for cleaning up the .csv files exported from Qualtrics so they can be loaded into R easily. Yours might differ, which is fine. I delete the second and third rows before loading the data, personally. 

#####DATA CLEANING#####


#What I am going to do here is just get the data in a format ideal for analysis, and you can do whatever you want with it from there (regression, multilevel model, etc.). See Hainmueller, Hopkins, & Yamamoto (2014) for the "gold standard" on estimating treatment effects from a conjoint analysis. 

#NOTE that if you have restricted randomization (as we sort of do between nuts and calories), there is a somewhat more complex analytic procedure that may be necessary to estimate the effects of each of those treatments. Our randomization dependency is fairly simply, but see Hainmueller et al. for more complex cases and the calculations necessary to estimate those effects. 

# Ideally, though, we restructure the data so that we have a separate row for each cereal for each trial for each respondent. So for us, with 6 respondents (ideally there would be way more), 10 trials and 2 cereals per trial, that means 120 rows. The columns in each row will be the traits associated with that cereal, and we will have a column indicating whether or not the respondent chose that cereal. We should also include columns for the respondent ID and also trial number so that we can account for variance attributable to respondent or trial (via something like clustered standard errors or random intercepts via MLM, etc.). 

#Note, however, that other data structures are possible and sometimes more appropriate. Leeper & Robinson (2020) have each row as a candidate pair, and the IVs are constructed as differences between the two candidates for each trial. That works well for their analysis because the attributes they are interested in were continuous. In our case, we have a lot of categorical variables for which I'm not sure how much such an approach makes sense.

#But first, let's just look at what the trait variables looks like

table(df$traits1a)

table(df$attributes)


#We want these separate out into distinct columns, but if we randomized the order of attributes (as we did here), it's a tiny bit complicated. Again, there are many ways to do this, and you may discover a more efficient method. This method should work though. 


#Separating trial variables into dummies for each cereal

table(df$Q4) #Beware Qualtrics trying to sabotage you by coding things '3' and '4' rather than '1' and '2'

#You can do this manually for each trial variable but I'm making a function so you can use that if you have lots of trials. The function takes a data frame, a vector of variable names, and a vector of numeric values representing Cereal A and Cereal B, respectively. This creates all the Cereal A variables before the Cereal B variables, so Cereal A for trial 1 is in column 1, but Cereal B for trial 1 is in column 11 (since there were 10 trials and thus 10 columns representing Cereal As before it). Again, there very well may be a more efficient way of doing this, but this works.

sep.trials <- function(data, vars, values) {
  d <- data[, vars]
  new <- as.data.frame(matrix(NA, ncol=2*ncol(d), nrow=nrow(d), byrow=FALSE))
  oldnames <- c(names(d))
  newnames1 <- paste(names(d), "c1", sep=".")
  newnames2 <- paste(names(d), "c2", sep=".")
  newnames <- append(newnames1, newnames2)
  for (i in 1:ncol(d)) {
    new[,i] <- ifelse(is.na(d[,i]), NA, 
                      ifelse(d[,i]==values[1], 1, 0)) 
    new[,i+ncol(d)] <- ifelse(is.na(d[,i]), NA, 
                              ifelse(d[,i]==values[1], 0, 1))
    new[,i] <- as.numeric(new[,i])
    new[,i+ncol(d)] <- as.numeric(new[,i+ncol(d)])
  }
  colnames(new)<-newnames
  return(new)
}

df.sep.trials <- as.data.frame(sep.trials(data=df, vars=c("Q4", "Q27", "Q28", "Q29", "Q30", "Q31", 
                                                          "Q32", "Q33", "Q34", "Q35"), 
                                     values=c("3", "4")))
head(df.sep.trials) 
class(df.sep.trials$Q4.c1)

df <- as.data.frame(cbind(df,df.sep.trials))
head(df)


#"Stack" the data so each row is a respondent-trial-cereal


dfl <- reshape(df, varying=list(c("Q4.c1", "Q27.c1", "Q28.c1", "Q29.c1", "Q30.c1", "Q31.c1", 
                                  "Q32.c1", "Q33.c1", "Q34.c1", "Q35.c1", 
                                  "Q4.c2", "Q27.c2", "Q28.c2", "Q29.c2", "Q30.c2", "Q31.c2", 
                                  "Q32.c2", "Q33.c2", "Q34.c2", "Q35.c2")), 
               v.names=c("chosen"), 
               timevar=c("cereal"), direction="long")

names(dfl)
table(dfl$id) #this is respondent id
table(dfl$cereal) #this is a respondent-trial-cereal
table(dfl$chosen) #1 = chosen; 0 = not chosen

#Making trial variable, so we have variable for cereals from the same trial
#Can do manually, but quicker with a little for-loop here.


table(dfl$cereal)
ntrials <- 10 #set ntrials to # of trials in your experiment
dfl$trial <- NA
table(dfl$trial)
for (i in 1:nrow(dfl)) {
    dfl[i,]$trial <- ifelse(dfl[i,]$cereal<=ntrials, dfl[i,]$cereal, 
                            ifelse(dfl[i,]$cereal>ntrials, dfl[i,]$cereal-ntrials, 999))
}
table(dfl$trial)


#Separate out the attribute and trait variables so they are separate columns

table(dfl$traits1a)
table(dfl$attributes)

#Since the order of traits is different for each person, using a similar method to that used in the js, where we obtain the index number of each attribute for each person first and then use that. This requires turning the "attributes" variable into a vector (within a vector) for each person

out <- strsplit(as.character(dfl$attributes),'\\|') #This turns attributes into lists separating each attribute label
out[1]

dfl$index.cal <- NA
dfl$index.sug <- NA
dfl$index.type <- NA
dfl$index.taste <- NA
dfl$index.marsh <- NA
dfl$index.nuts <- NA
dfl$index.mas <- NA

for (i in 1:nrow(dfl)) {
  dfl[i,]$index.cal <- which("Calories" == out[[i]])
  dfl[i,]$index.sug <- which("Grams of sugar" == out[[i]])
  dfl[i,]$index.type <- which("Type" == out[[i]])
  dfl[i,]$index.taste <- which("Taste Description" == out[[i]])
  dfl[i,]$index.marsh <- which("Marshmallows?" == out[[i]])
  dfl[i,]$index.nuts <- which("Nuts?" == out[[i]])
  dfl[i,]$index.mas <- which("Mascot" == out[[i]])
} 
table(dfl$index.cal)
table(dfl$index.sug)
table(dfl$index.type)
table(dfl$index.taste)
table(dfl$index.marsh)
table(dfl$index.nuts)
table(dfl$index.mas)


#Ok, now I want to make a "traits" variable that is just the traits for that trial (as of now, we have 10 traits variables - 1 for each trial - in every row). 

table(dfl$traits1a)
#You could theoretically use a series of ifelse statements here, but there is a limit to how many levels they can have (20 it seems?), and I always run into other weird problems that way, so here is another for-loop.

#data frame of just traits variables in order they are in in dfl (THE ORDER IS IMPORTANT HERE)
df.t <- dfl[, c("traits1a", 
               "traits2a", 
               "traits3a", 
               "traits4a", 
               "traits5a",  
               "traits6a",  
               "traits7a",  
               "traits8a",  
               "traits9a",  
               "traits10a", 
               "traits1b", 
               "traits2b", 
               "traits3b", 
               "traits4b", 
               "traits5b",  
               "traits6b",  
               "traits7b",  
               "traits8b",  
               "traits9b",  
               "traits10b")]


table(dfl$cereal)
ncereals <- 20
dfl$traits <- NA
for (i in 1:nrow(dfl)) {
  n <- dfl[i,]$cereal
  dfl[i,]$traits <- as.character(df.t[i,n])
 }
table(dfl$traits)

#Ok now we have a "traits" variable that is just the traits for that cereal!


#Now, we want to separate out the components of the traits variable just like we did with the attributes variable. 

out2 <- strsplit(as.character(dfl$traits),'\\|') #This turns attributes into lists separating each attribute label
out2[1]

#Now creating separate variables for each trait should be "relatively" simple. 

out2[[5]]
out2[[1]][2]
out2[[5]][dfl[5,]$index.cal]

dfl$calories <- NA
dfl$sugar <- NA
dfl$type <- NA
dfl$taste <- NA
dfl$marsh <- NA
dfl$nuts <- NA
dfl$mascot <- NA
for (i in 1:nrow(dfl)) {
  dfl[i,]$calories <- out2[[i]][dfl[i,]$index.cal]
  dfl[i,]$sugar <- out2[[i]][dfl[i,]$index.sug]
  dfl[i,]$type <- out2[[i]][dfl[i,]$index.type]
  dfl[i,]$taste <- out2[[i]][dfl[i,]$index.taste]
  dfl[i,]$marsh <- out2[[i]][dfl[i,]$index.marsh]
  dfl[i,]$nuts <- out2[[i]][dfl[i,]$index.nuts]
  dfl[i,]$mascot <- out2[[i]][dfl[i,]$index.mas]
}
dfl$calories <- as.numeric(dfl$calories)
table(dfl$calories)
#Making a binary variable just in case. 
dfl$cal01 <- as.factor(ifelse(is.na(dfl$calories), NA, 
                              ifelse(dfl$calories<151, "low", "high")))
dfl$cal01 <- relevel(dfl$cal01, "low")
table(dfl$cal01)
dfl$sugar <- as.numeric(dfl$sugar)
table(dfl$sugar)
table(dfl$type)
table(dfl$taste)
#Let's make that binary variable. 
adult.words <- "earthy|efficient|healthy|hearty|like a yoga mat|like healthy fruits|
like success|like the American Dream|mushroom-y?|umami"
dfl$taste.adult <- as.factor(ifelse(is.na(dfl$taste), NA, 
                          ifelse(grepl(adult.words, dfl$taste)==T, "adult", "kid")))
dfl$taste.adult <- relevel(dfl$taste.adult, "kid")
table(dfl$taste.adult)
table(dfl$marsh)
table(dfl$nuts)
dfl$nuts <- as.factor(dfl$nuts) #particularly important to make this a factor variable since using in an interaction later and releveling.
table(dfl$mascot)


#Woohoo! Let's export it just in case :-)
#Need to drop the variables that are lists though to save as .csv

dflx <- subset(dfl, select=-c(traits))
write.csv(dflx,
          file="WICSS-SampleData-forR-stacked.csv", row.names=F)


#####DATA ANALYSIS#####

#Just a linear regression with SEs clustered on participant id to show common approach.

#BUT, see additional considerations for attributes for which randomization is restricted (here, nuts and calories). If you include both 'nuts' and 'cal01' in the model, you will see that perfect collinearity leads to one of them being dropped automatically. That is because we designed the conjoint such that low calories corresponds perfectly with there not being nuts, and high calories with there being nuts. There is no "work around" here if you want to keep calories as binary. They are perfectly redundant variables due to your design and so we have no variance to work with. 

#Here's the unclustered SE version for familiarity's sake
lm1x <- lm(chosen ~ cal01 + sugar + taste.adult + marsh + nuts + mascot, dfl)
summary(lm1)

#With clustered SEs
lm1xc <- lm_robust(chosen ~ cal01 + sugar + taste.adult + marsh + nuts + mascot, dfl, clusters=id, ci=T)
summary(lm1)

#There are many ways dependency based on randomization might manifest that doesn't lead to total redundancy. See Hainmueller, Hopkins, & Yamamoto (2014) for one possible manifestation in the "immigration" experiment, where education and occupation are dependent to some degree. Our case is a tad different in that one of the variables is a continuous variable whose range depends on levels of the other variable (which is binary). Calories ranges from 50-150 when nuts=no and 300-500 when nuts=yes. As such, we have variation in both variables at all levels of each variable. However, we have good reason to expect the effect of calories may differ across levels of 'nuts', and the same for the effect of 'nuts' across levels of calories. So, we can use interactions and relevel the variables across models to properly identify whether the effects of these treatments interact. 

#For the effect of calories when nuts=no, just run the interaction model. This will also tell us whether or not we even need to worry about this since if the interaction is insignificant, it suggests the effects don't vary across levels of one another.

#Here's the unclustered SE version for familiarity's sake:
lm1 <- lm(chosen ~ calories*nuts + sugar + taste.adult + marsh + mascot, dfl)
summary(lm1)

#Clustered SEs:
lm1c <- lm_robust(chosen ~ calories*nuts + sugar + taste.adult + marsh + mascot, dfl, cluster=id, ci=T)
summary(lm1c)
#b = -.00010, SE = .00158, p = .952

#But the interaction is insignificant, suggesting we can just use the main effects model. 

#Here's the unclustered SE version for familiarity's sake:
lmME <- lm(chosen ~ calories + nuts + sugar + taste.adult + marsh + mascot, dfl)
summary(lmME)

#Clustered SEs:
lmMEc <- lm_robust(chosen ~ calories + nuts + sugar + taste.adult + marsh + mascot, dfl, cluster=id, ci=T)
summary(lmMEc)

#However, just so you have it, here is how we'd decompose the interaction if it were significant.

#For the effect of calories when nuts=yes, rerun the interaction model with 'nuts' releveled. 
lm2c <- lm_robust(chosen ~ calories*relevel(nuts, "yes") + sugar + taste.adult + marsh + mascot, dfl, cluster=id, ci=T)
summary(lm2c)
#b = .00172, SE = .000617, p < .05

#For the effect of nuts when calories are low, rerun the interaction model with 'calories' releveled. We will just relevel it to the midpoint of the 'low' interval here (100 calories). When you add a number to a continuous variable, that number becomes the new zero-point, and with interaction models, the marginal effect of a variable contained in an interaction is its effect when the other variable = 0 (so when I relevel 'calories' here, the marginal effect of 'nuts' will be its effect when calories = 100). 
lm3c <- lm_robust(chosen ~ I(calories+100)*nuts + sugar + taste.adult + marsh + mascot, dfl, cluster=id, ci=T)
summary(lm3c)
#b = -.8787, SE = .4689, p = .124

#Now when calories is at the midpoint of 'high' (400)
lm4c <- lm_robust(chosen ~ I(calories+400)*nuts + sugar + taste.adult + marsh + mascot, dfl, cluster=id, ci=T)
summary(lm4c)
#b = -1.425, SE = .9607, p = .203

#It's a tad more complicated if there is simply no variance in one variable at certain levels of the other or the two variables are categorical, such as with Hainmueller et al.'s immigration experiment, where certain occupations only exist above a certain threshold of education. When that is the case, there is a formula for using interactions between dummy variables to calculate the regression coefficients for each category of each variable. See Hainmueller et al. 


#Multi-level model version not working here - likely because of the data just being me taking the survey 6 times and answering randomly... but this is what it might look like. You could also then consider using random effects for 'calories' that vary across levels of 'nuts' or something like that to get at the randomization dependency issues, if you wanted. 

lmer1 <- lmer(chosen ~ calories + nuts + sugar + taste.adult + marsh + mascot + (1|id) + (1|trial), dfl)
summary(lmer1)


#Okay a quick coefficient plot, because that's what everyone wants from a conjoint. 

#Could be as easy as this if you just use lm:
coefplot(lmME)

#Or for more customization and use with other models: 

lmMEc$term
lmMEc$coefficients
lmMEc$conf.low
lmMEc$conf.high


dotmat <- as.data.frame(cbind(lmMEc$coefficients, lmMEc$conf.low, lmMEc$conf.high))
dotmat
row.names(dotmat)

gg1 <- ggplot(dotmat, aes(x=row.names(dotmat), y=V1)) +
  geom_pointrange(position=position_dodge(.4), 
                  aes(ymin=V2, ymax=V3)) + 
  geom_hline(yintercept=0, linetype="dotted") + 
  theme_bw() + 
  xlab("") +
  theme(text = element_text(size=20)) + 
  ylab("Average Marginal Component Effect (AMCE)") +
  ggtitle("Coefficient Plot")  + 
  theme(plot.title = element_text(hjust = 0.5)) +
  coord_flip()

gg1

#This still isn't very pretty, but you can use the world of ggplot options now to customize this to your liking.


#You might also check out a package called 'cjoint' by Barari et al. (2018), which apparently does all the modelling and plotting for you. I have not really looked into it yet, but it seems like it only really accepts factor/categorical attributes (maybe?), and if you have dependent randomization at all, it requires inputting the conjoint design into r. See https://cran.r-project.org/web/packages/cjoint/cjoint.pdf. 


#Good luck!!!


