// THIS CODE WAS BUILT HEAVILY ON FOUNDATIONS PROVIDED BY THOMAS LEEPER (https://github.com/leeper/conjoint-example) AND KYLE DROPP (http://www.kyledropp.com/conjoint.html)

// Define the Dimensions
var attRaw = ["Calories", "Grams of sugar", "Type", "Taste Description", "Marshmallows?", "Nuts?", "Mascot"];
var att = ["Calories", "Grams of sugar", "Type", "Taste Description", "Marshmallows?", "Nuts?", "Mascot"];
var attributes = ["","","","","","",""];

// Randomize the Order of Dimensions (avoid recency and primacy)
for (i=0; i<attRaw.length;i++ ){
var rand1 = Math.floor(Math.random()*((attRaw.length-i)-0));
attributes[i] = att[rand1];
att.splice(rand1,1);}

var traits_a = [1,2,3,4,5,6,7];
var traits_b = [1,2,3,4,5,6,7];

// Create variables for the index for each attribute to use in JS code for each question
var vcal_index = attributes.indexOf("Calories");
var vsug_index = attributes.indexOf("Grams of sugar");
var vtype_index = attributes.indexOf("Type");
var vtaste_index = attributes.indexOf("Taste Description");
var vmarsh_index = attributes.indexOf("Marshmallows?");
var vnuts_index = attributes.indexOf("Nuts?");
var vmasc_index = attributes.indexOf("Mascot");
