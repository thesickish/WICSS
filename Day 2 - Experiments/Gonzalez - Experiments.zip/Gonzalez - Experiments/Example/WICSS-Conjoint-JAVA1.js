// THIS CODE WAS BUILT HEAVILY ON FOUNDATIONS PROVIDED BY THOMAS LEEPER (https://github.com/leeper/conjoint-example) AND KYLE DROPP (http://www.kyledropp.com/conjoint.html)

// import seeded random number generator code
// https://github.com/davidbau/seedrandom/blob/released/seedrandom.min.js
!function(a,b){function c(c,j,k){var n=[];j=1==j?{entropy:!0}:j||{};var s=g(f(j.entropy?[c,i(a)]:null==c?h():c,3),n),t=new d(n),u=function(){for(var a=t.g(m),b=p,c=0;q>a;)a=(a+c)*l,b*=l,c=t.g(1);for(;a>=r;)a/=2,b/=2,c>>>=1;return(a+c)/b};return u.int32=function(){return 0|t.g(4)},u.quick=function(){return t.g(4)/4294967296},u["double"]=u,g(i(t.S),a),(j.pass||k||function(a,c,d,f){return f&&(f.S&&e(f,t),a.state=function(){return e(t,{})}),d?(b[o]=a,c):a})(u,s,"global"in j?j.global:this==b,j.state)}function d(a){var b,c=a.length,d=this,e=0,f=d.i=d.j=0,g=d.S=[];for(c||(a=[c++]);l>e;)g[e]=e++;for(e=0;l>e;e++)g[e]=g[f=s&f+a[e%c]+(b=g[e])],g[f]=b;(d.g=function(a){for(var b,c=0,e=d.i,f=d.j,g=d.S;a--;)b=g[e=s&e+1],c=c*l+g[s&(g[e]=g[f=s&f+b])+(g[f]=b)];return d.i=e,d.j=f,c})(l)}function e(a,b){return b.i=a.i,b.j=a.j,b.S=a.S.slice(),b}function f(a,b){var c,d=[],e=typeof a;if(b&&"object"==e)for(c in a)try{d.push(f(a[c],b-1))}catch(g){}return d.length?d:"string"==e?a:a+"\0"}function g(a,b){for(var c,d=a+"",e=0;e<d.length;)b[s&e]=s&(c^=19*b[s&e])+d.charCodeAt(e++);return i(b)}function h(){try{if(j)return i(j.randomBytes(l));var b=new Uint8Array(l);return(k.crypto||k.msCrypto).getRandomValues(b),i(b)}catch(c){var d=k.navigator,e=d&&d.plugins;return[+new Date,k,e,k.screen,i(a)]}}function i(a){return String.fromCharCode.apply(0,a)}var j,k=this,l=256,m=6,n=52,o="random",p=b.pow(l,m),q=b.pow(2,n),r=2*q,s=l-1;if(b["seed"+o]=c,g(b.random(),a),"object"==typeof module&&module.exports){module.exports=c;try{j=require("crypto")}catch(t){}}else"function"==typeof define&&define.amd&&define(function(){return c})}([],Math);

function randomNumber(min, max) {
    return Math.round(Math.random() * (max - min) + min);
}

// seed random number generator from embedded data fields
//Every time you paste this into a new question in Qualtrics, uncomment the next seed variable code and comment the previous one

// conjoint profile 1
Math.seedrandom('${e://Field/seed1}');
// conjoint profile 2
//Math.seedrandom('${e://Field/seed2}');
// conjoint profile 3
//Math.seedrandom('${e://Field/seed3}');
// conjoint profile 4
//Math.seedrandom('${e://Field/seed4}');
// conjoint profile 5
//Math.seedrandom('${e://Field/seed5}');
// conjoint profile 6
//Math.seedrandom('${e://Field/seed6}');
// conjoint profile 7
//Math.seedrandom('${e://Field/seed7}');
// conjoint profile 8
//Math.seedrandom('${e://Field/seed8}');
// conjoint profile 9
//Math.seedrandom('${e://Field/seed9}');
// conjoint profile 10
//Math.seedrandom('${e://Field/seed10}');


// Create Variables for Traits associated with each dimension.

// Calories should vary between 50 and 500 per serving, but this should be heavily dependent on whether or not nuts are contained in the cereal. As such, we make the range of calories dependent
// on the nuts variable (so we will make the nuts variable first)

//This flips a coin (so to say) so that people wither get nuts + high calories or no nuts + low calories (with calories still being an interval rather than a fixed number)
if (Math.random() >= 0.5) {
    var vnuts = "no";
    var vcala = randomNumber(50,150).toString();
    var vcalb= randomNumber(50,150).toString();
} else {
  var vnuts = "yes";
  var vcala = randomNumber(300,500).toString();
  var vcalb= randomNumber(300,500).toString();
}

//Note that # of calories is really more of a binary variable now (low vs high) than a continuous one (although the exact values can certainly be
// taken into account in analyses as well). The decision of how the variable should manifest (categorical, continuous) is entirely up to you, but you should consider theory, believability, and
// statistical power. See below on how this affects our operationalization of the "taste" variable.

//NOTE: Some variables need to be set separately for Cereal A and B; others don't. Basically, it depends on how the variables are called at the end of the script, which is deteremined by
// whether the variable is a single value or a range of possible values to choose from later. Here, vcal is called just by name, and so if we didn't make separate variables for each cereal,
// both A and B would get the same randomly generated value. But for vtaste, for example, the variable is a list of 10 words from which we randomly choose one later on.

// Sugar should just vary randomly between 5 and 25 grams per serving
var vsuga = randomNumber(5,25).toString();
var vsugb = randomNumber(5,25).toString();

//NOTE: The above numbers are taken from a uniform distribution. If you want to utilize another distribution, such as a normal/Gaussian distribution, you need to create a new function that does this.
// I have seen various functions that do this. I recommend taking a look at Stefano Balietti's github page: http://nodegame.github.io/JSUS/docs/lib/random.js.html

//Here, we flip a coin again because instead of just randomly choosing from a list of possible taste descriptors, we are really just interested in the distinction between two categories of
// descriptions: kid-oriented versus adult-oriented. This improves our statistical power for analyses because taste is potentially a binary variable now (kid vs adult) rather than a 20-category variables
// (although the exact categories can certainly be separated out and taken into account in analyses as well). The decision of how the variable should manifest is entirely up to you, but you should
// consider theory, believability, and statistical power.

if (Math.random() >= 0.5) {
    var vtastea = ["SWEET", "like my childhood rolled into every bite", "like a sugary rainbow", "like cake", "colorful", "like fun", "like donuts", "magical", "sparkly", "like candy"];
} else {
    var vtastea = ["healthy", "hearty", "like a yoga mat", "like the American Dream", "mushroom-y?", "earthy", "umami", "like success", "like healthy fruits", "efficient"];
}

if (Math.random() >= 0.5) {
    var vtasteb = ["SWEET", "like my childhood rolled into every bite", "like a sugary rainbow", "like cake", "colorful", "like fun", "like donuts", "magical", "sparkly", "like candy"];
} else {
    var vtasteb = ["healthy", "hearty", "like a yoga mat", "like the American Dream", "mushroom-y?", "earthy", "umami", "like success", "like healthy fruits", "efficient"];
}


//For Marshmallows and mascot, we just want a list of possible values to randomly select from later.
var vmarsh = ["yes", "no"];
var vmasc = ["colorful bird with beanie hat", "condescending owl with glasses", "muscular panther", "a bicep", "laid back prairie dog", "war cat"];


// Function for setting cereal type approximately proportionately
function getType(){
  // 60% oats; 15% flakes; 15% puffs; 10% crispies
  var n = Math.floor(Math.random()*100);
  if (n<10) {
    var out = 2;
  } else if (n <25) {
    var out = 1;
  } else if (n<40) {
    var out = 0;
  } else {
    var out = 3;
  }
  var vtype = ["flakes", "puffs", "crispies", "oats"];
  return vtype[out];
}

// Use math.random to randomly select traits for each dimension for Cereal A that is a list; just call variables directly if the variable already returns a single value
traits_a[vcal_index] = vcala;
traits_a[vsug_index] = vsuga;
traits_a[vtype_index] = getType();
traits_a[vtaste_index] = vtastea[Math.floor(Math.random()*vtastea.length)];
traits_a[vmarsh_index] = vmarsh[Math.floor(Math.random()*vmarsh.length)];
traits_a[vnuts_index] = vnuts;
traits_a[vmasc_index] = vmasc[Math.floor(Math.random()*vmasc.length)];

// Use math.random to randomly select traits for each dimension for Cereal B that is a list; just call variables directly if the variable already returns a single value
traits_b[vcal_index] = vcalb;
traits_b[vsug_index] = vsugb;
traits_b[vtype_index] = getType();
traits_b[vtaste_index] = vtasteb[Math.floor(Math.random()*vtasteb.length)];
traits_b[vmarsh_index] = vmarsh[Math.floor(Math.random()*vmarsh.length)];
traits_b[vnuts_index] = vnuts;
traits_b[vmasc_index] = vmasc[Math.floor(Math.random()*vmasc.length)];


// Create list of variables to use when setting traits and attributes
a_list = ["a1","a2","a3","a4","a5","a6","a7"];
b_list = ["b1","b2","b3","b4","b5","b6","b7"];

att_list = ["att1","att2","att3","att4","att5","att6","att7"];

// set html values for traits in conjoint table
for(i=0;i<7;i++){
    document.getElementById(att_list[i]).innerHTML= attributes[i];
    document.getElementById(a_list[i]).innerHTML = traits_a[i];
    document.getElementById(b_list[i]).innerHTML = traits_b[i];
}

// store values as embedded data fields
Qualtrics.SurveyEngine.setEmbeddedData('atts1', att_list.join("|"));
Qualtrics.SurveyEngine.setEmbeddedData('traits1a', traits_a.join("|"));
Qualtrics.SurveyEngine.setEmbeddedData('traits1b', traits_b.join("|"));

//Every time you paste this into a new question in Qualtrics, uncomment the next "traits" embedded data code and comment the previous one

//Qualtrics.SurveyEngine.setEmbeddedData('traits2a', traits_a.join("|"));
//Qualtrics.SurveyEngine.setEmbeddedData('traits2b', traits_b.join("|"));

//Qualtrics.SurveyEngine.setEmbeddedData('traits3a', traits_a.join("|"));
//Qualtrics.SurveyEngine.setEmbeddedData('traits3b', traits_b.join("|"));

//Qualtrics.SurveyEngine.setEmbeddedData('traits4a', traits_a.join("|"));
//Qualtrics.SurveyEngine.setEmbeddedData('traits4b', traits_b.join("|"));

//Qualtrics.SurveyEngine.setEmbeddedData('traits5a', traits_a.join("|"));
//Qualtrics.SurveyEngine.setEmbeddedData('traits5b', traits_b.join("|"));

//Qualtrics.SurveyEngine.setEmbeddedData('traits6a', traits_a.join("|"));
//Qualtrics.SurveyEngine.setEmbeddedData('traits6b', traits_b.join("|"));

//Qualtrics.SurveyEngine.setEmbeddedData('traits7a', traits_a.join("|"));
//Qualtrics.SurveyEngine.setEmbeddedData('traits7b', traits_b.join("|"));

//Qualtrics.SurveyEngine.setEmbeddedData('traits8a', traits_a.join("|"));
//Qualtrics.SurveyEngine.setEmbeddedData('traits8b', traits_b.join("|"));

//Qualtrics.SurveyEngine.setEmbeddedData('traits9a', traits_a.join("|"));
//Qualtrics.SurveyEngine.setEmbeddedData('traits9b', traits_b.join("|"));

//Qualtrics.SurveyEngine.setEmbeddedData('traits10a', traits_a.join("|"));
//Qualtrics.SurveyEngine.setEmbeddedData('traits10b', traits_b.join("|"));
