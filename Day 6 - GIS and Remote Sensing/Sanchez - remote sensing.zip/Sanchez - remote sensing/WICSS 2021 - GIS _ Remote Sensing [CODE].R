install.packages(pkg="raster")  # This might be installed already
install.packages(pkg="rgdal")   # This might be installed already
install.packages('RStoolbox')
install.packages(pkg='e1071')
install.packages("pROC")

library(rgdal)
library(raster)
library(RStoolbox)
library(e1071)
library(pROC)

#
# Exercise 1
#

wdir <- "C:/your/working/folder"  # Change this string to point to the folder where you saved the collection of images
rx <- glob2rx("*LC08_L1TP_172035_20130331_20170505_01_T1*.tif$")
band_names <- list.files(wdir, pattern=rx, full.names=TRUE)

window <- extent(c(485000,515000,3971000,3986000))  # Geographical extent of study area
band_stack <- stack(band_names)
band_brick <- brick(band_stack) 
raqqah_brick <- crop(band_brick, window)

plot(raqqah_brick[[2]],
     col = gray((0:100)/100),
     main = "Raqqah | Band 2 (Blue) | 2017-10-21)")

hist(raqqah_brick[[2]], 
     main="Raqqah | Band 2 (Blue) | 2017-10-21)")

#
# Exercise 2
#

# K-means

k <- 20 
set.seed(as.numeric(Sys.time()))
k_clusters <- unsuperClass(brick(as(raqqah_brick,"SpatialGridDataFrame")), 
                           nSamples = 1000, 
                           nClasses = k, 
                           nStarts = 10)

colors <- rainbow(k)
plot(as(k_clusters$map, "SpatialGridDataFrame"), 
     col = colors)

writeRaster(x=k_clusters$map,
            filename="kmeans_clusters.tif",
            format="GTiff", 
            datatype="INT2S",
            overwrite=TRUE)

# Preparing training and validation samples
###???
sample <- raster(file.path('C:/your/working/folder','sample.tif'))
labels <- as.array(as(sample,"SpatialGridDataFrame")@data[,1])
classes <- unique(labels)
classes <- sort(classes[!is.na(classes)])
n_classes <- length(classes) 

test_rate <- 0.3
test_k <- vector("list",n_classes)
for (class in 1:n_classes){ 
   test_n <- floor(sum(labels==class,na.rm = TRUE)*test_rate)
   test_k[[class]] <- sample(which(labels == classes[class],arr.ind=TRUE)[,1], 
                             size = test_n, 
                             replace = FALSE)
}
test_ID <- sort(unlist(test_k))
train_ID <- (1:length(labels))[-test_ID]
train_ID <- train_ID[!is.na(labels[-test_ID])]

train <- data.frame(b1=raqqah_brick[[1]]@data@values[train_ID],
                    b2=raqqah_brick[[2]]@data@values[train_ID],
                    b3=raqqah_brick[[3]]@data@values[train_ID],
                    b4=raqqah_brick[[4]]@data@values[train_ID],
                    b5=raqqah_brick[[5]]@data@values[train_ID],
                    b6=raqqah_brick[[6]]@data@values[train_ID],
                    b7=raqqah_brick[[7]]@data@values[train_ID],
                    b9=raqqah_brick[[8]]@data@values[train_ID],
                    labels=as.factor(labels[train_ID]))

test <- data.frame(b1=raqqah_brick[[1]]@data@values[test_ID],
                   b2=raqqah_brick[[2]]@data@values[test_ID],
                   b3=raqqah_brick[[3]]@data@values[test_ID],
                   b4=raqqah_brick[[4]]@data@values[test_ID],
                   b5=raqqah_brick[[5]]@data@values[test_ID],
                   b6=raqqah_brick[[6]]@data@values[test_ID],
                   b7=raqqah_brick[[7]]@data@values[test_ID],
                   b9=raqqah_brick[[8]]@data@values[test_ID],
                   labels=as.factor(labels[test_ID]))

target <- data.frame(b1=raqqah_brick[[1]]@data@values[is.na(labels)],
                     b2=raqqah_brick[[2]]@data@values[is.na(labels)],
                     b3=raqqah_brick[[3]]@data@values[is.na(labels)],
                     b4=raqqah_brick[[4]]@data@values[is.na(labels)],
                     b5=raqqah_brick[[5]]@data@values[is.na(labels)],
                     b6=raqqah_brick[[6]]@data@values[is.na(labels)],
                     b7=raqqah_brick[[7]]@data@values[is.na(labels)],
                     b9=raqqah_brick[[8]]@data@values[is.na(labels)])

# Support Vector Machines

svm_model <- svm(labels ~ ., data = train)
svm_pred <- predict(svm_model, newdata=target)
svm_classified <- labels
svm_classified[is.na(svm_classified)] <- svm_pred
svm_df <- as(raqqah_brick[[1]], "SpatialGridDataFrame")
svm_df@data <- data.frame(class=svm_classified)

colors <- rainbow(5)
plot(svm_df, col=colors)

writeRaster(x = raster(svm_df),
            filename="svm_prediction.tif",
            format="GTiff", 
            datatype="INT2S",
            overwrite=TRUE)

# Naive Bayes

bayes_model <- naiveBayes(labels ~ ., data = train)
bayes_pred <- predict(bayes_model, newdata=target, type = 'class')
bayes_classified <- labels
bayes_classified[is.na(bayes_classified)] <- bayes_pred
bayes_df <- as(raqqah_brick[[1]], "SpatialGridDataFrame")
bayes_df@data <- data.frame(class=bayes_classified)

colors <- rainbow(5)
plot(bayes_df,col=colors)

writeRaster(x = raster(bayes_df),
            filename="bayes_prediction.tif",
            format="GTiff", 
            datatype="INT2S",
            overwrite=TRUE)

#
# Exercise 3
#

# Validation of SVM

svm_test <- predict(svm_model, newdata=test) 

svm_confusion <- matrix(numeric(n_classes^2), ncol=n_classes)
for (model_k in 1:n_classes)
   for (truth_k in 1:n_classes)
      svm_confusion[model_k,truth_k] <- length(which(svm_test == classes[model_k] & 
                                                     test$labels == classes[truth_k]))

svm_accuracy <- sum(diag(svm_confusion))/sum(svm_confusion)

svm_recall <- numeric(n_classes)
for (k in 1:n_classes) 
   svm_recall[k] <- svm_confusion[k,k]/sum(svm_confusion[,k])

svm_omission <- 1 - svm_recall

svm_precision <- numeric(n_classes)
for (k in 1:n_classes)
   svm_precision[k] <- svm_confusion[k,k]/sum(svm_confusion[k,])

svm_commission <- 1 - svm_precision

svm_F1 <- 2*svm_recall*svm_precision/(svm_recall+svm_precision)

svm_confusion_model_sums <- apply(svm_confusion,1,sum)
svm_confusion_test_sums <- apply(svm_confusion,2,sum)
svm_obs <- sum(svm_confusion)*sum(diag(svm_confusion))-
           sum(svm_confusion_model_sums*svm_confusion_test_sums)
svm_exp <- sum(svm_confusion)^2 -sum(svm_confusion_model_sums* svm_confusion_test_sums)
svm_kappa <- svm_obs/svm_exp

svm_auc <- multiclass.roc(response=as.numeric(test$labels),
                          predictor=as.numeric(svm_test))

# Validation of Naive bayes results

bayes_test <- predict(bayes_model, newdata=test)

bayes_confusion <- matrix(numeric(n_classes^2), ncol=n_classes)

for (model_k in 1:n_classes)
   for (truth_k in 1:n_classes)
      bayes_confusion[model_k,truth_k] <- length(which(bayes_test == classes[model_k] & 
                                                       test$labels == classes[truth_k]))

bayes_accuracy <- sum(diag(bayes_confusion))/sum(bayes_confusion)

bayes_recall <- numeric(n_classes)
for (k in 1:n_classes) 
   bayes_recall[k] <- bayes_confusion[k,k]/sum(bayes_confusion[,k])

bayes_omission <- 1 - bayes_recall

bayes_precision <- numeric(n_classes)
for (k in 1:n_classes)
   bayes_precision[k] <- bayes_confusion[k,k]/sum(bayes_confusion[k,])

bayes_comission <- 1 - bayes_precision

bayes_F1 <- 2*bayes_recall*bayes_precision/(bayes_recall+bayes_precision)

bayes_confusion_model_sums <- apply(bayes_confusion,1,sum)
bayes_confusion_test_sums <- apply(bayes_confusion,2,sum)
bayes_obs <- sum(bayes_confusion)*
             sum(diag(bayes_confusion))-
             sum(bayes_confusion_model_sums*bayes_confusion_test_sums)
bayes_exp <- sum(bayes_confusion)^2 -
             sum(bayes_confusion_model_sums*bayes_confusion_test_sums)
bayes_kappa <- bayes_obs/bayes_exp

bayes_auc <- multiclass.roc(response=as.numeric(test$labels), 
                            predictor=as.numeric(bayes_test))